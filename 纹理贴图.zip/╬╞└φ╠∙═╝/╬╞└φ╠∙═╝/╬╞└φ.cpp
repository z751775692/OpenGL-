//#include <Gl/glew.h>
//#include <GL/glut.h>
//#include "stb_image.h"
//#include <stdlib.h>
//#include <iostream>
//
//void init(void)
//{    
//   glClearColor (0.0, 0.0, 0.0, 0.0);
//   glShadeModel(GL_FLAT);
//   glEnable(GL_DEPTH_TEST);
//
//   glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
//}
//
//void display(void)
//{
//	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
//
//	unsigned int texture;
//	glGenTextures(1, &texture);
//	glBindTexture(GL_TEXTURE_2D, texture);
//	// Ϊ��ǰ�󶨵������������û��ơ����˷�ʽ
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);   
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//	//���ز���������
//	int width, height, nrChannels;
//	unsigned char *data = stbi_load("container.jpg", &width, &height,&nrChannels, 0);
//	if (data)
//	{
//		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
//		glGenerateMipmap(GL_TEXTURE_2D);
//	}
//	else
//	{
//		std::cout << "Failed to load texture" << std::endl;
//	}
//	stbi_image_free(data);
//
//
//	glEnable(GL_TEXTURE_2D);	//��������������
//	glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);	//���û�ͼģʽ�����ʹ��������������ɫ�����ٿ���ԭ������ɫ
//	
//
//	glBegin(GL_QUADS);
//	glTexCoord2f(0.0,0.0);glVertex3f(-2.0,-1.0,0.0);	//��������Ͷ�������һ��ָ��
//	glTexCoord2f(0.0,1.0);glVertex3f(-2.0,1.0,0.0);
//	glTexCoord2f(1.0,1.0);glVertex3f(0.0,1.0,0.0);
//	glTexCoord2f(1.0,0.0);glVertex3f(0.0,-1.0,0.0);
//	glEnd();
//
//	glFlush();
//	glDisable(GL_TEXTURE_2D);
//}
//
//void reshape(int w,int h)
//{
//	glViewport(0,0,(GLsizei)w,(GLsizei)h);
//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	gluPerspective(60.0,(GLfloat)w/(GLfloat)h,1.0,30.0);
//	glMatrixMode(GL_MODELVIEW);
//	glLoadIdentity();
//	glTranslatef(0.0,0.0,-3.6);
//}
//
//int main(int argc,char **argv)
//{
//	glutInit(&argc,argv);
//	glutInitDisplayMode(GLUT_DEPTH | GLUT_RGBA | GLUT_SINGLE);
//	glutInitWindowSize(500,500);
//	glutCreateWindow("����--�滻ģʽ");
//
//	init();
//	glutDisplayFunc(display);
//	glutReshapeFunc(reshape);
//	
//	glutMainLoop();
//	return 0;
//}
